var searchData=
[
  ['integer_20functions',['Integer functions',['../a00237.html',1,'']]]
];
