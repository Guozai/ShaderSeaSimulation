var searchData=
[
  ['exponential_20functions',['Exponential functions',['../a00144.html',1,'']]],
  ['experimental_20extensions',['Experimental extensions',['../a00154.html',1,'']]]
];
