var searchData=
[
  ['vector_20relational_20functions',['Vector Relational Functions',['../a00241.html',1,'']]]
];
