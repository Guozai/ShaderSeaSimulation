var searchData=
[
  ['template_20types',['Template types',['../a00151.html',1,'']]],
  ['types',['Types',['../a00149.html',1,'']]]
];
