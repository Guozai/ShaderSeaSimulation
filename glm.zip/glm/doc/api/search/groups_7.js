var searchData=
[
  ['precision_20types',['Precision types',['../a00150.html',1,'']]]
];
