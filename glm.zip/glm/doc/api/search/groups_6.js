var searchData=
[
  ['matrix_20functions',['Matrix functions',['../a00238.html',1,'']]]
];
